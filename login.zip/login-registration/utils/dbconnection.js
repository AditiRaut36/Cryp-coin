const mysql = require('mysql2');

const dbConnection = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Rehapade@123',
    database: 'nodejs_login'
});

module.exports = dbConnection.promise();